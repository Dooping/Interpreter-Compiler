package Values;

public interface IValue {
	
}
