package Types;

public interface Type {
	
}
